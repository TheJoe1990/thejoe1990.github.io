# plugin.program.aftermath
Aftermath Wizard

Aftermath Wizard was created to help the Kodi community out and help get rid of the broken personal wizards that are floating around. As this is a work in progress, I would highly recommend the use of a repository, but if you prefer not to, there is a built-in auto-updater.

Currently, this version of the wizard supports:

Trakt Saving:
 - Gaia
 - Placenta
 - Magicality
 - Exodus Redux
 - Trakt
 
RD/PM Saving:
 - Gaia
 - ResolveURL
 - URLResolver
 
API Key Saving:
 - OpenSubtitles
 - Orion
 - Placenta
 - Gaia
 - Magicality
 - Extended Info Script
 - Metahandler
 - script.module.metadatautils
 - Exodus Redux
 
If you don't see these in your menus, don't be alarmed... it's just because you dont have them installed. They are supported, however ;)